import { faBroom, faCircleNotch, faExclamationTriangle, faMagnifyingGlassPlus, faServer, faTools } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import type { ColumnDef } from "@tanstack/react-table";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router";
import Button from "../components/Button.js";
import FloatingCardButton from "../components/FloatingCardButton.js";
import InputField from "../components/form-fields/InputField.js";
import SelectField from "../components/form-fields/SelectField.js";
import SourceDot from "../components/SourceDot.js";
import Table from "../components/table/Table.js";
import TableSearch from "../components/table/TableSearch.js";
import { useTable } from "../hooks/useTable.js";
import { NavBarContent } from "../layout/NavBarContext.js";
import { API_NAMES, API_URLS, MULTI_INSTANCE, useAppStore } from "../store.js";
import type { TouchlinkDevice } from "../types.js";
import { sendMessage } from "../websocket/WebSocketManager.js";

type TouchlinkTableData = {
    sourceIdx: number;
    touchlinkDevice: TouchlinkDevice;
    friendlyName: string | undefined;
    identifyInProgress: boolean;
    resetInProgress: boolean;
};

export default function TouchlinkPage() {
    const { t } = useTranslation(["touchlink", "common", "zigbee", "settings"]);
    const bridgeInfo = useAppStore((state) => state.bridgeInfo);
    const touchlinkDevices = useAppStore((state) => state.touchlinkDevices);
    const devices = useAppStore((state) => state.devices);
    const touchlinkIdentifyInProgress = useAppStore((state) => state.touchlinkIdentifyInProgress);
    const touchlinkResetInProgress = useAppStore((state) => state.touchlinkResetInProgress);
    const touchlinkScanInProgress = useAppStore((state) => Object.values(state.touchlinkScanInProgress).some((v) => v));
    const setTouchlinkIdentifyInProgress = useAppStore((state) => state.setTouchlinkIdentifyInProgress);
    const setTouchlinkResetInProgress = useAppStore((state) => state.setTouchlinkResetInProgress);
    const setTouchlinkScan = useAppStore((state) => state.setTouchlinkScan);
    const [scanIdx, setScanIdx] = useState(0);
    const [hueExtPanId, setHueExtPanId] = useState<string>("");
    const [hueSerialNumbersRaw, setHueSerialNumbersRaw] = useState<string>("");
    const [hueSerialNumbers, setHueSerialNumbers] = useState<string[]>([]);

    // biome-ignore lint/correctness/useExhaustiveDependencies: specific trigger
    useEffect(() => {
        setHueExtPanId(bridgeInfo[scanIdx].network?.extended_pan_id ?? "");
    }, [scanIdx]);

    useEffect(() => {
        setHueSerialNumbers(hueSerialNumbersRaw ? hueSerialNumbersRaw.replaceAll(" ", "").split(",") : []);
    }, [hueSerialNumbersRaw]);

    const data = useMemo((): TouchlinkTableData[] => {
        const renderDevices: TouchlinkTableData[] = [];

        for (let sourceIdx = 0; sourceIdx < API_URLS.length; sourceIdx++) {
            const sourceDevices = devices[sourceIdx];

            for (const touchlinkDevice of touchlinkDevices[sourceIdx]) {
                renderDevices.push({
                    sourceIdx,
                    touchlinkDevice,
                    friendlyName: sourceDevices.find((d) => d.ieee_address === touchlinkDevice.ieee_address)?.friendly_name,
                    identifyInProgress: touchlinkIdentifyInProgress[sourceIdx],
                    resetInProgress: touchlinkResetInProgress[sourceIdx],
                });
            }
        }

        return renderDevices;
    }, [devices, touchlinkDevices, touchlinkIdentifyInProgress, touchlinkResetInProgress]);

    const onScanClick = useCallback(
        async (sourceIdx: number) => {
            setTouchlinkScan(sourceIdx, { inProgress: true, devices: [] });
            await sendMessage(sourceIdx, "bridge/request/touchlink/scan", "");
        },
        [setTouchlinkScan],
    );

    const onIdentifyClick = useCallback(
        async ([sourceIdx, device]: [number, TouchlinkDevice]): Promise<void> => {
            setTouchlinkIdentifyInProgress(sourceIdx, true);
            await sendMessage(sourceIdx, "bridge/request/touchlink/identify", device);
        },
        [setTouchlinkIdentifyInProgress],
    );

    const onResetClick = useCallback(
        async ([sourceIdx, device]: [number, TouchlinkDevice]): Promise<void> => {
            setTouchlinkResetInProgress(sourceIdx, true);
            await sendMessage(sourceIdx, "bridge/request/touchlink/factory_reset", device);
        },
        [setTouchlinkResetInProgress],
    );

    const onHueResetApply = useCallback(async () => {
        await sendMessage(scanIdx, "bridge/request/action", {
            action: "philips_hue_factory_reset",
            params: {
                // 0x-format
                extended_pan_id: hueExtPanId,
                serial_numbers: hueSerialNumbers,
            },
        });
        setHueSerialNumbersRaw("");
    }, [scanIdx, hueExtPanId, hueSerialNumbers]);

    const isHueResetValid = useMemo(() => {
        if ((!hueExtPanId || /^0x[a-fA-F0-9]{16}$/.test(hueExtPanId)) && Array.isArray(hueSerialNumbers) && hueSerialNumbers.length > 0) {
            return hueSerialNumbers.every((sn) => /^[a-fA-F0-9]{6}$/.test(sn));
        }

        return false;
    }, [hueExtPanId, hueSerialNumbers]);

    const columns = useMemo<ColumnDef<TouchlinkTableData, unknown>[]>(
        () => [
            {
                id: "source",
                size: 60,
                header: () => (
                    <span title={t(($) => $.source, { ns: "common" })}>
                        <FontAwesomeIcon icon={faServer} />
                    </span>
                ),
                accessorFn: ({ sourceIdx }) => API_NAMES[sourceIdx],
                cell: ({
                    row: {
                        original: { sourceIdx },
                    },
                }) => <SourceDot idx={sourceIdx} nameClassName="hidden md:inline-block" />,
                filterFn: "equals",
                meta: {
                    filterVariant: "select",
                    showFacetedOccurrences: true,
                },
            },
            {
                id: "ieee_address",
                minSize: 175,
                header: t(($) => $.ieee_address, { ns: "zigbee" }),
                accessorFn: ({ touchlinkDevice }) => touchlinkDevice.ieee_address,
                cell: ({
                    row: {
                        original: { sourceIdx, touchlinkDevice, friendlyName },
                    },
                }) =>
                    friendlyName ? (
                        <div className="min-w-0">
                            <Link to={`/device/${sourceIdx}/${touchlinkDevice.ieee_address}/info`} className="link link-hover truncate font-mono">
                                {touchlinkDevice.ieee_address}
                            </Link>
                        </div>
                    ) : (
                        touchlinkDevice.ieee_address
                    ),
                // XXX: for some reason, the default sorting algorithm does not sort properly
                sortingFn: (rowA, rowB) => rowA.original.touchlinkDevice.ieee_address.localeCompare(rowB.original.touchlinkDevice.ieee_address),
                filterFn: "includesString",
                meta: {
                    filterVariant: "text",
                },
            },
            {
                id: "friendly_name",
                minSize: 175,
                header: t(($) => $.friendly_name, { ns: "common" }),
                accessorFn: ({ friendlyName }) => friendlyName,
                filterFn: "includesString",
                sortingFn: (rowA, rowB) =>
                    (rowA.original.friendlyName ?? rowA.original.touchlinkDevice.ieee_address).localeCompare(
                        rowB.original.friendlyName ?? rowB.original.touchlinkDevice.ieee_address,
                    ),
                meta: {
                    filterVariant: "text",
                    textFaceted: true,
                },
            },
            {
                id: "channel",
                minSize: 175,
                header: t(($) => $.channel, { ns: "zigbee" }),
                accessorFn: ({ touchlinkDevice }) => touchlinkDevice.channel,
                filterFn: "weakEquals",
                meta: {
                    filterVariant: "select",
                },
            },
            {
                id: "actions",
                minSize: 130,
                cell: ({
                    row: {
                        original: { sourceIdx, touchlinkDevice, resetInProgress, identifyInProgress },
                    },
                }) => {
                    return (
                        <div className="join join-horizontal">
                            <Button<[number, TouchlinkDevice]>
                                disabled={resetInProgress || identifyInProgress}
                                item={[sourceIdx, touchlinkDevice]}
                                title={t(($) => $.identify)}
                                className="btn btn-sm btn-square btn-outline btn-primary join-item"
                                onClick={onIdentifyClick}
                            >
                                <FontAwesomeIcon icon={identifyInProgress ? faCircleNotch : faExclamationTriangle} spin={identifyInProgress} />
                            </Button>
                            <Button<[number, TouchlinkDevice]>
                                disabled={resetInProgress || identifyInProgress}
                                item={[sourceIdx, touchlinkDevice]}
                                title={t(($) => $.factory_reset)}
                                className="btn btn-sm btn-square btn-outline btn-error join-item"
                                onClick={onResetClick}
                            >
                                <FontAwesomeIcon icon={resetInProgress ? faCircleNotch : faBroom} spin={resetInProgress} />
                            </Button>
                        </div>
                    );
                },
                enableSorting: false,
                enableColumnFilter: false,
                enableGlobalFilter: false,
            },
        ],
        [t, onIdentifyClick, onResetClick],
    );

    const table = useTable({
        id: "touchlink-devices",
        columns,
        data,
        visibleColumns: { source: MULTI_INSTANCE },
        sorting: [{ id: "friendly_name", desc: false }],
    });

    return touchlinkScanInProgress ? (
        <div className="flex flex-row justify-center items-center gap-2">
            <span className="loading loading-infinity loading-xl" />
        </div>
    ) : (
        <>
            <NavBarContent>
                <TableSearch {...table} />
            </NavBarContent>

            <div className="flex flex-row flex-wrap justify-center items-center gap-2 mb-3">
                {MULTI_INSTANCE && (
                    <SelectField
                        name="scan_idx_picker"
                        label={t(($) => $.scan_source)}
                        value={scanIdx}
                        onChange={(e) => !e.target.validationMessage && !!e.target.value && setScanIdx(Number.parseInt(e.target.value, 10))}
                        className="select"
                    >
                        <option value="" disabled>
                            {t(($) => $.select_scan_source)}
                        </option>
                        {API_NAMES.map((name, idx) => (
                            <option key={name} value={idx}>
                                {name}
                            </option>
                        ))}
                    </SelectField>
                )}
                <fieldset className="fieldset self-end">
                    <Button<number> className="btn btn-outline btn-primary" item={scanIdx} onClick={onScanClick} disabled={touchlinkScanInProgress}>
                        <FontAwesomeIcon icon={faMagnifyingGlassPlus} />
                        {t(($) => $.scan)}
                    </Button>
                </fieldset>
                <fieldset className="fieldset self-end ml-auto">
                    <FloatingCardButton
                        placement="bottom-end"
                        canApply={isHueResetValid}
                        onApply={onHueResetApply}
                        buttonClassName={"btn btn-outline btn-error"}
                        buttonIcon={faTools}
                        buttonTitle={t(($) => $.philips_hue_reset)}
                        title={t(($) => $.philips_hue_reset)}
                    >
                        {MULTI_INSTANCE && (
                            <SelectField
                                name="scan_idx_picker"
                                label={t(($) => $.source, { ns: "common" })}
                                value={scanIdx}
                                onChange={(e) => !e.target.validationMessage && !!e.target.value && setScanIdx(Number.parseInt(e.target.value, 10))}
                                className="select"
                            >
                                <option value="" disabled>
                                    {t(($) => $.source, { ns: "common" })}
                                </option>
                                {API_NAMES.map((name, idx) => (
                                    <option key={name} value={idx}>
                                        {name}
                                    </option>
                                ))}
                            </SelectField>
                        )}
                        <InputField
                            name="serial_numbers"
                            label={t(($) => $.serial_numbers)}
                            type="text"
                            value={hueSerialNumbersRaw}
                            onChange={(e) => !e.target.validationMessage && setHueSerialNumbersRaw(e.target.value)}
                        />
                        <div className="collapse collapse-arrow">
                            <input type="checkbox" />
                            <div className="collapse-title font-semibold px-0">{t(($) => $.advanced, { ns: "settings" })}</div>
                            <div className="collapse-content text-sm pb-2 px-2">
                                <InputField
                                    name="extended_pan_id"
                                    label={t(($) => $.extended_pan_id, { ns: "zigbee" })}
                                    type="text"
                                    value={hueExtPanId}
                                    onChange={(e) => !e.target.validationMessage && setHueExtPanId(e.target.value)}
                                />
                            </div>
                        </div>
                    </FloatingCardButton>
                </fieldset>
            </div>

            <div className="mb-5">
                <Table id="touchlink-devices" {...table} />
            </div>
        </>
    );
}
