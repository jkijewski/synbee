import ReconnectingWebSocket from 'reconnecting-websocket';
import store, { Base64String, Extension, LogMessage, OnlineOrOffline } from './store';
import { BridgeInfo, BridgeState, BridgeDefinitions, Device, DeviceState, Group, TouchLinkDevice } from './types';
import {
    debounceArgs,
    isSecurePage,
    randomString,
    sanitizeGraph,
    stringifyWithPreservingUndefinedAsNull,
} from './utils';

import NiceModal from '@ebay/nice-modal-react';
import { Store } from 'react-notifications-component';
import keyBy from 'lodash/keyBy';

import { GraphI } from './components/map/types';
import local from 'store2';

const TOKEN_LOCAL_STORAGE_ITEM_NAME = "z2m-token-v2";
const AUTH_FLAG_LOCAL_STORAGE_ITEM_NAME = "z2m-auth-v2";
const UNAUTHORIZED_ERROR_CODE = 4401;

const AVAILABILITY_FEATURE_TOPIC_ENDING = "/availability";


interface Message {
    topic: string;
    payload: string | Record<string, unknown> | Record<string, unknown>[] | string[];
}

const blacklistedMessages: string[] = [
    'MQTT publish'
];

const showNotify = (level: string, message: string, filter: boolean): void => {
    if (filter) {
        const { bridgeInfo } = store.getState();
        const notificationFilter = blacklistedMessages.concat(bridgeInfo?.config?.frontend?.notification_filter ?? []);

        if (notificationFilter.some((val) => (new RegExp(val)).test(message))) {
            return;
        }
    }

    switch (level) {
        case "error":
        case "warning":
            Store.addNotification({
                message: message,
                type: "danger",
                container: "bottom-right",
                dismiss: {
                    duration: 5000
                }
            });

            break;
        case "info":
            Store.addNotification({
                message: message,
                type: "info",
                container: "bottom-right",
                dismiss: {
                    duration: 5000
                }
            });
            break;

        default:
            break;
    }
};

interface ResponseWithStatus {
    status: "ok" | "error";
    data: unknown;
    error?: string;
    transaction?: string;
}
interface TouchllinkScanResponse extends ResponseWithStatus {
    data: {
        found: TouchLinkDevice[];
    };
}
interface Callable {
    (): void;
}

const apiDebounceDelay = 250;

class Api {
    url: string;
    socket: ReconnectingWebSocket;
    requests: Map<string, [Callable, Callable]> = new Map<string, [Callable, Callable]>();
    transactionNumber = 1;
    transactionRndPrefix: string;
    constructor(url: string) {
        this.url = url;
        this.transactionRndPrefix = randomString(5);
    }
    send = (topic: string, payload: Record<string, unknown> = {}): Promise<void> => {
        console.debug("Calling API", { topic, payload });

        if (topic.startsWith('bridge/request/')) {
            const transaction = `${this.transactionRndPrefix}-${this.transactionNumber++}`;
            const promise = new Promise<void>((resolve, reject) => {
                this.requests.set(transaction, [resolve, reject]);
            });
            this.socket.send(stringifyWithPreservingUndefinedAsNull({ topic, payload: { ...payload, transaction } }));
            return promise;
        } else {
            this.socket.send(stringifyWithPreservingUndefinedAsNull({ topic, payload }));
            return Promise.resolve();
        }
    }

    urlProvider = async (): Promise<string> => {
        const promise = new Promise<string>((resolve) => {
            const url = new URL(this.url)
            let token = new URLSearchParams(window.location.search).get("token")
                ?? local.get<string>(TOKEN_LOCAL_STORAGE_ITEM_NAME);
            const authRequired = !!local.get(AUTH_FLAG_LOCAL_STORAGE_ITEM_NAME);
            if (authRequired) {
                if (!token) {
                    NiceModal.show('auth-form', { onAuth: (token: string) => {
                        local.set(TOKEN_LOCAL_STORAGE_ITEM_NAME, token);
                        url.searchParams.append("token", token);
                        resolve(url.toString());
                    }});
                    return;
                }
                url.searchParams.append("token", token);
            }
            resolve(url.toString());
        });

        return promise;
    }

    connect(): void {
        this.socket = new ReconnectingWebSocket(this.urlProvider);
        this.socket.addEventListener("message", this.onMessage);
        this.socket.addEventListener("close", this.onClose);
    }
    private processDeviceStateMessage = debounceArgs((messages: Message[]): void => {
        let { deviceStates } = store.getState();
        messages.forEach(data => {
            deviceStates = { ...deviceStates, ...{ [data.topic]: { ...deviceStates[data.topic], ...(data.payload as DeviceState) } } };
        });
        store.setState({ deviceStates });
    }, { trailing: true, maxWait: apiDebounceDelay }) as (data: Message) => void;

    private processBridgeMessage = (data: Message): void => {
        switch (data.topic) {
            case "bridge/info":
                store.setState({
                    bridgeInfo: data.payload as unknown as BridgeInfo
                });
                break;

            case "bridge/state":
                store.setState({
                    bridgeState: data.payload as BridgeState
                });
                break;

            case "bridge/devices":
                store.setState({
                    devices: keyBy(data.payload as unknown as Device[], 'ieee_address')
                });
                break;

            case "bridge/definitions":
                store.setState({
                    bridgeDefinitions: data.payload as unknown as BridgeDefinitions
                });
                break;

            case "bridge/groups":
                store.setState({
                    groups: data.payload as unknown as Group[]
                })
                break;


            case "bridge/extensions":
                store.setState({ extensions: data.payload as Extension[] });
                break;

            case "bridge/logging":
                {
                    const { logs, logsLimit } = store.getState();
                    const newLogs = [...logs.slice(-logsLimit)];
                    newLogs.push({ ...(data.payload as unknown as LogMessage), timestamp: new Date() } as LogMessage);
                    store.setState({ logs: newLogs });
                    const log = data.payload as unknown as LogMessage;
                    if (log.level !== 'debug') {
                        showNotify(log.level, log.message, true);
                    }
                }
                break;

            case "bridge/response/networkmap":
                {
                    const response = data.payload as unknown as ResponseWithStatus;
                    const stateUpdate = { networkGraphIsLoading: false };
                    if (response.status === "ok") {
                        stateUpdate['networkGraph'] = sanitizeGraph((response.data as {
                            value: unknown
                        }).value as GraphI);
                    }
                    store.setState(stateUpdate);
                }
                break;


            case "bridge/response/touchlink/scan":
                {
                    const { status, data: payloadData } = data.payload as unknown as TouchllinkScanResponse;
                    const stateUpdate = { touchlinkScanInProgress: false };
                    if (status === "ok") {
                        stateUpdate['touchlinkDevices'] = payloadData.found;
                    }
                    store.setState(stateUpdate);

                }
                break;

            case "bridge/response/touchlink/identify":
                store.setState({ touchlinkIdentifyInProgress: false });
                break;

            case "bridge/response/touchlink/factory_reset":
                store.setState({ touchlinkResetInProgress: false });
                break;


            case "bridge/response/backup":
                const { data: { zip } } = data.payload as { data: { zip: Base64String } };
                store.setState({ backup: zip, preparingBackup: false });
                break;

            case "bridge/response/device/generate_external_definition":
                const { data: { source, id } } = data.payload as { data: { source: Base64String, id: string } };
                const generatedExternalDefinitions = {...store.getState().generatedExternalDefinitions, [id]: source};
                store.setState({ generatedExternalDefinitions });
                break;

            default:
                break;
        }
        if (data.topic.startsWith("bridge/response/")) {
            const log = data.payload as unknown as ResponseWithStatus;
            if (log.status === "error") {
                showNotify(log.status, log.error ?? "Unknown error", false);
            }
            this.resolvePromises(log);
        }
    }

    private processAvailabilityMessage = debounceArgs((messages: Message[]): void => {
        let { availability } = store.getState();
        messages.forEach(data => {
            const friendlyName = data.topic.split(AVAILABILITY_FEATURE_TOPIC_ENDING, 1)[0];
            availability = { ...availability, ...{ [friendlyName]: data.payload as OnlineOrOffline } };
        });
        store.setState({ availability });
    }, { trailing: true, maxWait: apiDebounceDelay }) as (data: Message) => void;

    private resolvePromises(message: ResponseWithStatus): void {
        const { transaction, status } = message;
        if (transaction !== undefined && this.requests.has(transaction)) {
            const [resolve, reject] = this.requests.get(transaction) as [Callable, Callable];
            if (status === "ok" || status === undefined) {
                resolve();
            } else {
                reject();
            }
            this.requests.delete(transaction);
        }
    }

    private onClose = (e: CloseEvent): void => {
        if (e.code === UNAUTHORIZED_ERROR_CODE) {
            local.set(AUTH_FLAG_LOCAL_STORAGE_ITEM_NAME, true);
            local.remove(TOKEN_LOCAL_STORAGE_ITEM_NAME);
            showNotify('error', "Unauthorized", false);
            setTimeout(() => {
                this.connect();
            }, 1000);
        }
    }

    private onMessage = (event: MessageEvent): void => {
        let data = {} as Message;
        try {
            data = JSON.parse(event.data) as Message;
            if (data.topic.endsWith(AVAILABILITY_FEATURE_TOPIC_ENDING)) {
                this.processAvailabilityMessage(data);
            } else if (data.topic.startsWith("bridge/")) {
                this.processBridgeMessage(data);
            } else {
                this.processDeviceStateMessage(data);
            }
        } catch (e) {
            showNotify('error', e.message, false);
            console.error(event.data);
        }

    }
}
const apiUrl = `${window.location.host}${document.location.pathname}api`;
const api = new Api(`${isSecurePage() ? 'wss' : 'ws'}://${apiUrl}`);
export default api;
